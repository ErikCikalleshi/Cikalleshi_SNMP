package sample;


public class ScanNetWorkThread implements Runnable{
    String subnet;
    ScanNetWorkThread(String subnet){
        this.subnet = "192.168.1.";
    }
    @Override
    public void run() {

    }
}
